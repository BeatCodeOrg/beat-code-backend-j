package com.beat.back.controler;

import com.beat.back.pojo.ResponseData;
import com.beat.back.pojo.UserDeliveryTest;
import com.beat.back.service.JudgeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("judge")
public class JudgeControler {
    @Autowired
    JudgeService judgeService;
    @PostMapping("getGrade")
    public ResponseData getTestRank(@RequestBody UserDeliveryTest userDeliveryTest){

       return      judgeService.getJudgeData(userDeliveryTest);
    }

    @PostMapping("getRankList")
    public ResponseData getRankList(){

        return      judgeService.getRankData();
    }
    @PostMapping("getCompile")
    public ResponseData getCompileTest(@RequestBody UserDeliveryTest userDeliveryTest){

        return      judgeService.getJudgeDataCompile(userDeliveryTest);
    }
}

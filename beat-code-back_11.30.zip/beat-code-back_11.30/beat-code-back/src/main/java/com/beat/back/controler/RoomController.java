package com.beat.back.controler;

import com.beat.back.pojo.JoinUserData;
import com.beat.back.pojo.ResponseData;
import com.beat.back.service.RoomService;
import com.beat.back.pojo.Room;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.*;

import java.io.IOException;

@RestController
@RequestMapping("/room")
public class RoomController {
@Autowired
RoomService service;
    @PostMapping("/create")
    public ResponseData<Room> createRoom(@RequestParam("userId") String userId) {
        return
                service.createNewRoom(userId);
    }
    @PostMapping("/start-exam/{roomCode}")
     public  ResponseData<Room> startExam(@PathVariable("roomCode") String roomCode) throws IOException {

        return
                service.startNewTest(roomCode);
    }
    @GetMapping("getRestTime")
     public  ResponseData getRestTime(){
         return
                 service.getRestTime();
    }
}

package com.beat.back.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BasicUserData {
    String roomCode;
    String username;
}

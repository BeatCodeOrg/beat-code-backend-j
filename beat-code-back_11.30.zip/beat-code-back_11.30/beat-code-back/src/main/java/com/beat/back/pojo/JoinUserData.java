package com.beat.back.pojo;

import lombok.Data;
import org.springframework.web.socket.WebSocketSession;

@Data
public class JoinUserData {
 String roomCode;
 String userName;

 WebSocketSession session;//保存的连接

    @Override
    public String toString() {
        return "{" +
                "roomCode:'" + roomCode + '\'' +
                ", userName:'" + userName + '\'' +
                '}';
    }
}


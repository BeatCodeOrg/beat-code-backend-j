package com.beat.back.pojo;

import lombok.Data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
@Data
public class Room {

     int id;

	 String roomCode;

	 String ownerId;

	 List <User> roomList;
}

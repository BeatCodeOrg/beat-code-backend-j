package com.beat.back.pojo;

import lombok.Data;

@Data
public class UserDeliveryTest {
    String sourceCode;
    String questionId;
    int grade;
    String username;

}

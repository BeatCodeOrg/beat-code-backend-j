package com.beat.back.service;

import com.beat.back.pojo.ResponseData;
import com.beat.back.pojo.UserDeliveryTest;

public interface JudgeService {
     public ResponseData getJudgeData(UserDeliveryTest userDeliveryTest);
     public ResponseData getRankData();

     public ResponseData getJudgeDataCompile(UserDeliveryTest userDeliveryTest);

}

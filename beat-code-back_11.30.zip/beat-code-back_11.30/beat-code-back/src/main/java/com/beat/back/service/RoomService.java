package com.beat.back.service;

import com.beat.back.pojo.ResponseData;
import com.beat.back.pojo.Room;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;


public interface RoomService {

    public ResponseData createNewRoom(String userId);

    public  ResponseData startNewTest(String roomCode) throws IOException;

    public  ResponseData getRestTime();

}

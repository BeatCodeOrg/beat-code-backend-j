package com.beat.back.service.impl;

import com.beat.back.pojo.ResponseData;
import com.beat.back.pojo.UserDeliveryTest;
import com.beat.back.service.JudgeService;
import com.beat.back.tools.Judge;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class JudgeImpl implements JudgeService {
   static  int userNumber ;
   public  static  int restTime = 120;
   List<UserDeliveryTest> userDeliveryTestList = new ArrayList<UserDeliveryTest>();
    @Override
    public ResponseData getJudgeData(UserDeliveryTest userDeliveryTest) {
        int grade = Judge.runCode(userDeliveryTest.getSourceCode(),1);
        userDeliveryTest.setGrade(grade);
        userDeliveryTestList.add(userDeliveryTest);
        return
                ResponseData.successResponse("判题成功！",userDeliveryTest);
    }

    @Override
    public ResponseData getRankData() {
        for (int i=0;i<userDeliveryTestList.size();i++){
            for (int j=i;j<userDeliveryTestList.size()-1;j++){
                if(userDeliveryTestList.get(j).getGrade() < userDeliveryTestList.get(j+1).getGrade()){
                    UserDeliveryTest swap = userDeliveryTestList.get(j);
                    userDeliveryTestList.set(j,userDeliveryTestList.get(j+1));
                    userDeliveryTestList.set(j+1,swap);
                }
            }
        }

        return
               ResponseData.successResponse("获得排行成功！",userDeliveryTestList);
    }

    @Override
    public ResponseData getJudgeDataCompile(UserDeliveryTest userDeliveryTest) {
        int grade = Judge.runCode(userDeliveryTest.getSourceCode(),1);
        userDeliveryTest.setGrade(grade);
        System.out.println("System COMPILE");
        return
                ResponseData.successResponse("判题成功！",userDeliveryTest);
    }


}

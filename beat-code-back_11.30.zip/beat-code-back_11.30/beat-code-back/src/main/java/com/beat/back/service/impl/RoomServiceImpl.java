package com.beat.back.service.impl;

import com.beat.back.pojo.JoinUserData;
import com.beat.back.pojo.Message;
import com.beat.back.pojo.ResponseData;
import com.beat.back.pojo.Room;
import com.beat.back.service.RoomService;
import com.beat.back.socket.RoomHandler;
import com.beat.back.tools.DataTools;
import com.google.gson.Gson;
import org.springframework.stereotype.Service;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketSession;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;

@Service
public class RoomServiceImpl implements RoomService {
    public    static Map<String,String> roomListMap;

    static {
        roomListMap = new HashMap();
    }

    public  static  synchronized  int putRoom(String roomId){
        if(roomListMap.get(roomId) !=null) return  -1;
        else {
            roomListMap.put(roomId,roomId);
            return  0;
        }
    }
    public  String genreatorRoomCode(int length){
           char [] roomCharList = {};
           Random random = new Random();
           for(int i=0;i<length;i++){
              int randomData =  random.nextInt(DataTools.code.length);
               roomCharList[i] = DataTools.code[randomData];
           }
           String roomCode = roomCharList.toString();
           //如果发生了小概率同时存在的房间号
          if(putRoom(roomCode) == -1){
              return  genreatorRoomCode(8);
          }
          else return  roomCode;
    }

    //利用自增
    @Override
    public ResponseData createNewRoom(String userId) {
        String roomCode = genreatorRoomCode(8);
        Room room = new Room();
        room.setRoomCode(roomCode);
        room.setOwnerId(userId);
        return  ResponseData.successResponse("创建房间成功！",room);
    }

    @Override
    public ResponseData startNewTest(String roomCode) throws IOException {

        List<JoinUserData> list =  RoomHandler.mapSessions.get(roomCode);
        JudgeImpl.userNumber =  list.size();
        Gson gson = new Gson();
        String message = gson.toJson(new Message("to next Page","to next Page",null));
        for(JoinUserData joinUserData : list){
           WebSocketSession session =  joinUserData.getSession();
           session.sendMessage(new TextMessage(message));
           session.close();
        }
        new Thread(new Runnable() {
            @Override
            public void run() {
                for(int i=0;i<120;i++){
                    if(JudgeImpl.restTime>0) JudgeImpl.restTime = JudgeImpl.restTime-1;
                    try {
                        Thread.sleep(1000);
                    } catch (InterruptedException e) {
                        throw new RuntimeException(e);
                    }
                }
            }
        }).start();
      return ResponseData.successResponse("success to close Page",null);
    }

    @Override
    public ResponseData getRestTime() {
        return ResponseData.successResponse("获取剩余的时间",JudgeImpl.restTime);
    }
}

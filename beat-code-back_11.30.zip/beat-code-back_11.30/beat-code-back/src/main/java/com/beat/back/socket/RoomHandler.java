package com.beat.back.socket;

import com.beat.back.pojo.BasicUserData;
import com.beat.back.pojo.JoinUserData;

import com.beat.back.pojo.Message;
import com.beat.back.service.RoomService;
import com.google.gson.Gson;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.socket.CloseStatus;
import org.springframework.web.socket.TextMessage;
import org.springframework.web.socket.WebSocketMessage;
import org.springframework.web.socket.WebSocketSession;
import org.springframework.web.socket.handler.TextWebSocketHandler;

import javax.websocket.*;
import javax.websocket.server.PathParam;
import javax.websocket.server.ServerEndpoint;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CopyOnWriteArrayList;


public class RoomHandler  extends TextWebSocketHandler {
    @Autowired
    RoomService roomService;

    //用来保存连接进来session ,可以共享出去
    public static List<WebSocketSession> sessions = new CopyOnWriteArrayList<>();

    public  static Map<String, List<JoinUserData>> mapSessions  = new HashMap<>();

    public  static  Map<String,List<BasicUserData>> userDataMessage = new HashMap();

    public static Map<WebSocketSession,String> socketStore = new HashMap<>();


    /**
     * 关闭连接进入这个方法处理，将session从 list中删除
     */
    @Override
    public void afterConnectionClosed(WebSocketSession session, CloseStatus status) throws Exception {
        System.out.println("Socket关闭 这个方法将从列表中找到房间号通知");

    }

    /**
     * 三次握手成功，进入这个方法处理，将session 加入list 中
     */
    @Override
    public void afterConnectionEstablished(WebSocketSession session) throws Exception {
        sessions.add(session);
    }

    /**
     * 处理客户发送的信息，将客户发送的信息转给其他用户
     */
    @Override
    public void handleMessage(WebSocketSession session, WebSocketMessage<?> message) throws Exception {
        String payLoad = (String) message.getPayload();
        Gson gson = new Gson();
        System.out.println(payLoad);
        JoinUserData joinUserData = gson.fromJson(payLoad, JoinUserData.class);
        String roomCode = joinUserData.getRoomCode(); //用户要加入房间的roomCode
         joinUserData.setSession(session);
         System.out.println("我是设置的ROOMCODE " +roomCode);
        List<JoinUserData> userRoomList = mapSessions.get(roomCode);
        List <BasicUserData> basicUserDataList  = userDataMessage.get(roomCode);
         if(userRoomList !=null) {
             userRoomList.add(joinUserData);
         }
         //如果为空的话
         else{
             userRoomList = new ArrayList();
             mapSessions.put(roomCode,userRoomList);
             userRoomList.add(joinUserData);//
         }
         if(basicUserDataList != null){
             basicUserDataList.add(new BasicUserData(joinUserData.getRoomCode(),joinUserData.getUserName()));
         }
         else{
             basicUserDataList = new ArrayList<>();
             basicUserDataList.add(new BasicUserData(joinUserData.getRoomCode(),joinUserData.getUserName()));
             userDataMessage.put(roomCode,basicUserDataList);
         }

         //给该房间的所有用户发送消息有新来的用户
         for(JoinUserData userData : userRoomList ){
             WebSocketSession roomSession =  userData.getSession();
             Message messageData = new Message();
             messageData.setType("new-user-join");
             messageData.setMessage("用户加入房间");
             List<BasicUserData>  list = userDataMessage.get(roomCode);
             messageData.setBody(list);
             String jsonString = gson.toJson(messageData);
             roomSession.sendMessage(new TextMessage(jsonString));
         }

    }




}

package com.beat.back.tools;

public class DataTools {
   public static final char[] code = "qwertyuiopasdfghjklzxcvbnm1234567890".toCharArray();

}

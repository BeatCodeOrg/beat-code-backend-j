package com.beat.back.tools;

import com.beat.back.pojo.Room;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class RoomCacheList {
    //roomList 用于存储正在内存当中的room

    public    static  Map<String,String> roomListMap;

    static {
         roomListMap = new HashMap();
    }

    public  static  synchronized  int putRoom(String roomId){
         if(roomListMap.get(roomId) !=null) return  -1;
         else {
             roomListMap.put(roomId,roomId);
             return  0;
         }
    }

}

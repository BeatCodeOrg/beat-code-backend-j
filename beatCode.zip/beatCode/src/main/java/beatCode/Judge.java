package beatCode;

import java.util.List;


public class Judge {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public List<Integer> evaluateCode(String code, int roomId, int userId) {
		// TODO Auto-generated method stub
		return null;
	}

}

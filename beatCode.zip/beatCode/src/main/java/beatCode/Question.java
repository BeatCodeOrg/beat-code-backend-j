package beatCode;



public class Question {

	 private Long id;

	    private String title;
	    private String description;
	    private String difficulty;
	    private String type;
	    private String skeletonCode;
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
	}

}

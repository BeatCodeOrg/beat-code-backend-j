package com.example.beatCode;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BeatCodeApplicationTests {

	@Test
	void contextLoads() {
	}

}

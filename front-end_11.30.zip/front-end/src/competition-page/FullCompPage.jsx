import { useEffect, useState } from "react";
import { Panel, PanelGroup } from "react-resizable-panels";
import { useNavigate } from "react-router-dom";
import CompetitionPage from "./CompetitionPage";
import ResizeHandle from "./ResizeHandle";
import ProgressBar from "./ProgressBar";
import Timer from "./Timer";

function FullCompPage() {
  // this will need to be passed in
    const players = [
      { username: 'Player1', testCasesPassed: 5, pointsGained: 50, progress: 50, bgcolor: '#2f7fff' },
      { username: 'Player2', testCasesPassed: 3, pointsGained: 30, progress: 30, bgcolor: '#ff2ff5' },
      // Add more players as needed
    ];
    let getSystemTime = 0;
    let submitStaus = false;
    const navigate = useNavigate();
    let submit = null;
    const handleTimerZero = () => {
      console.log('handleTimerZero called');
      console.log('players:', players);
       submit();
      navigate('/gameover', { state: { players:players } });
    };
    const submitEvent = function(target){
        submit = target;
    }
 
    return (
      <>
        <div className="flex flex-col h-screen">
          <div className="top-bar flex justify-end px-5 pt-3">
            <Timer onTimerZero={handleTimerZero} />
            <ProgressBar players={players} height={30} />
          </div>
          <div className="full-competition-page flex-grow flex">
              <PanelGroup autoSaveId="full-competition-page" direction="horizontal">
                <Panel defaultSizePercentage={35}>
                  <div className="left-problem-desc" style={{padding: '20px' }}>
                    <h2 className="problem-desc-title p-3 text-3xl font-bold tracking-wider">DESCRIPTION</h2>
                    <div className="selected-categories"></div>
                    <p className="problem-desc p-3 font-medium">Given an array of integers `nums` and an integer `target`, return indices of the two numbers such that they add up to `target`</p>
                  </div>
                </Panel>
                <ResizeHandle />
                <Panel defaultSizePercentage={65}>
                  <div className="right-IDE p-4">
                    <CompetitionPage  submitEvent ={submitEvent} />
                  </div>
                </Panel>
              </PanelGroup>
          </div>
        </div>
      </>
    );
  }

export default FullCompPage;
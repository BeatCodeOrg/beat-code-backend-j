const ad = 'admin'+Math.floor(Math.random()*100);
console.log(ad);